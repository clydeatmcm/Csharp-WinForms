﻿namespace CodeChum
{
    partial class HelloWorld
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textDisplayLabel = new Label();
            SuspendLayout();
            // 
            // textDisplayLabel
            // 
            textDisplayLabel.AutoSize = true;
            textDisplayLabel.Location = new Point(349, 124);
            textDisplayLabel.Name = "textDisplayLabel";
            textDisplayLabel.Size = new Size(73, 15);
            textDisplayLabel.TabIndex = 0;
            textDisplayLabel.Text = "Hello World!";
            // 
            // HelloWorld
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(textDisplayLabel);
            Name = "HelloWorld";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label textDisplayLabel;
    }
}
